import unittest
from tkinter import *
from Ventana import ventana
from cargar_archivo import CargarArchivo


class Pruebas(unittest.TestCase):

   
    def test_se_puede_crear_un_objeto_ventana(self):
        #prueba que se puede crear el objeto ventana
        interfaz=ventana()
      

    def test_puedo_instanciar_cargar_archivo_con_un_parametro(self):
        #prueba crear un objeto cargar_archivo con 1 parametro Rodo
        archivo=CargarArchivo("Rodo")

        #prueba crear un objeto cargar_archivo con 1 parametro Rodo
        archivo=CargarArchivo("auxiliar")


        #prueba crear un obtejo cargar_archivo con 1 parametro Mercadolibre
        archivo=CargarArchivo("Mercadolibre")

        #prueba crear un objeto cargar_archivo con 1 parametro Fravega
        archivo=CargarArchivo("Fravega")
        
        #prueba crear un objeto cargar_archivo con 1 parametro Garbarino
        archivo=CargarArchivo("Garbarino")

    def test_check_buttons_comienzan_en_none(self):
        interfaz2=ventana()
        #Marketplace1 comienzan en none
        mercadolibre=interfaz2.marketplace1
        self.assertTrue(mercadolibre==None)

        #Marketplace2 comienzan en none
        garbarino=interfaz2.marketplace2
        self.assertTrue(garbarino==None)

        #Marketplace3 comienzan en none
        fravega=interfaz2.marketplace3
        self.assertTrue(fravega==None)

        #Marketplace4 comienzan en none
        rodo=interfaz2.marketplace4
        self.assertTrue(rodo==None)

        
       
        

if __name__ == "__main__":
    unittest.main()