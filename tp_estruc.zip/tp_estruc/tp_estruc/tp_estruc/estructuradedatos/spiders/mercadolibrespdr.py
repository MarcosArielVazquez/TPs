import scrapy
from scrapy.crawler import CrawlerProcess
import csv


class MercadoLibreSpider(scrapy.Spider):

    name = 'botmercadolibre' #Nombre del bot

    def __init__(self, busqueda):
        self.producto = busqueda
        self.start_urls = ['https://listado.mercadolibre.com.ar/'+self.producto]

    def parse(self, response):

        for buscar in response.css('.andes-card--padding-default'):
            titulo_minusculas = buscar.css('.ui-search-item__title::text').get().lower()
            pagina= "Mercadolibre"

            yield{

            'precio': buscar.css('.ui-search-price__second-line .price-tag-fraction::text').get(),
            'titulo': " ".join(titulo_minusculas.split()),
            'link': buscar.css('.ui-search-link::attr("href")').get(),
            'categoria': [response.css('.ui-search-breadcrumb__title::text').get(), response.css('.andes-breadcrumb__item:nth-child(1) span::text').get()],
            'pagina': pagina
            }



        #Avanzar a la pagina siguiente
        pagina_siguiente = response.css('.andes-pagination__button--next .ui-search-link::attr("href")').get()
        if pagina_siguiente is not None:
            yield response.follow(pagina_siguiente, self.parse)



