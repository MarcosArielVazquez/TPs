import scrapy
from scrapy.crawler import CrawlerProcess


class FravegaSpider(scrapy.Spider):
    name = 'botfravega'

    def __init__(self, busqueda):
        self.contador = 2
        self.busqueda =busqueda
        #Cuando no se especifica lo buscado fravega muestra todos sus productos
        #para evitar eso inventamos una url
        if self.busqueda=="":

            self.url = 'https://www.fravega.com/l/?keyword='+"ASDADASDAFWGJIKWOI45378DJWOIDHNIAWU"
        else:
            self.url= 'https://www.fravega.com/l/?keyword='+self.busqueda
        self.start_urls = [self.url]


    def parse(self, response):
        for j in response.css('.hlRWOw'):

            nombre=j.css('a::attr("href")').get()
            if('/p/' in nombre or '-' in nombre):
                nombre = nombre.replace('/p/', '')
                nombre = nombre.replace('-', ' ')
            for _ in range(7):
                nombre = nombre[:-1]

            yield{
            'precio': j.css('.egaLpU::text').get().split()[1],
            'titulo': nombre,
            'link': "https://www.fravega.com"+j.css('a::attr("href")').get(),
            'categoria': [response.css('.fvCOsJ::text').get(), response.css('.cnlUAR::text').get()],
            'pagina': "Fravega"
            }



        next_page = 'https://www.fravega.com/l/?keyword='+self.busqueda+'&page='+ str(self.contador)
        if next_page  is not None and response.xpath('//*[@id="__next"]/div[3]/section[1]/div[2]/div/p/text()').get() != "No hay resultados que coincidan con tu búsqueda":

            self.contador+=1
            yield response.follow(next_page, self.parse)

