import scrapy
from scrapy.crawler import CrawlerProcess


class RodoSpider(scrapy.Spider):
    name = 'rodospdr'
    def __init__(self,busqueda):
        self.start_urls = ['https://rodo.com.ar/catalogsearch/result/?q='+busqueda]

    def parse(self, response):
        for j in response.css('.item.last'):
            precio_con_signo = j.css('.price::text').get().split(",")[0]
            titulo_minusculas = j.css('.product-name a::text').get().lower()
            yield{
            'precio': precio_con_signo.split()[1],
            'titulo': " ".join(titulo_minusculas.split()),
            'link': j.css('a::attr("href")').get(),
            'categoria': j.css('.product-name a::text').get(),
            'pagina': "Rodo"
            }

        next_page = response.css('.i-next::attr("href")').get()
        if next_page is not None:
            yield response.follow(next_page, self.parse)

