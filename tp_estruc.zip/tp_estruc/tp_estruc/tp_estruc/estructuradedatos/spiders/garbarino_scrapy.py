import scrapy
from scrapy.crawler import CrawlerProcess



class GarbarinoSpider(scrapy.Spider):
    name = 'botgarbarino'

    def __init__(self, busqueda):
        self.contador = 1
        self.producto = busqueda
        self.start_urls = ['https://www.garbarino.com/q/'+self.producto+'/srch?q='+self.producto]

    #allowed_domains = ['s']

    def parse(self, response):
        for buscar in response.css('.itemBox--info'):
            titulo_minusculas = buscar.css('.itemBox--title ::text').get().lower()
            yield{
                'precio': buscar.css('.value-item ::text').get()[1::],
                'titulo': " ".join(titulo_minusculas.split()),
                'link': "https://www.garbarino.com"+buscar.css('a::attr("href")').extract()[0],
                'categoria': buscar.css('.itemBox--title ::text').get(),
                'pagina': "Garbarino"

            }

        next_page = 'https://www.garbarino.com/q/'+self.producto+'/srch?page='+ str(self.contador) +'&q='+self.producto
        if next_page is not None and response.css('.gb-error-title::text').get() != "No hay resultados para esta búsqueda":
            self.contador+=1
            yield response.follow(next_page, self.parse)








