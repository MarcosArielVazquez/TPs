import json
import shutil
import csv
from datetime import date
from datetime import datetime

class CargarArchivo:

    def __init__(self, nombre_archivo):

        #Asigno las tiendas donde buscar
        self.nombre_archivo = nombre_archivo
        self.contador=1

        #Creo un diccionario donde se van a guardar los productos cargados desde el .CSV
        self.diccionario={}


    def obtener_diccionario(self):

        if(self.nombre_archivo != None):
            archivo_a_leer = self.nombre_archivo
            with open("tp_estruc/estructuradedatos/"+archivo_a_leer, "r", encoding="utf-8") as lugar_de_guardados:#agregue utf8

                lector = csv.DictReader(lugar_de_guardados, delimiter=",")
                for linea in lector:

                    self.diccionario['Elemento'+str(self.contador)]=[linea['titulo'],linea['precio'],linea['link'],
                    linea['categoria'], linea['pagina'], str(datetime.now())] #agrege str(datetime.now())] por que daba error json)

                    self.contador=self.contador+1

        return self.diccionario