import csv
from tkinter import *
from spiders.garbarino_scrapy import GarbarinoSpider
from spiders.mercadolibrespdr import MercadoLibreSpider
from spiders.fravegaspdr import FravegaSpider
from spiders.rodospdr import RodoSpider
from scrapy.crawler import CrawlerProcess
from cargar_archivo import CargarArchivo
from Buscador import Buscador
from os import remove
import os.path



class ventana:

    def __init__(self):

        #Creo la ventana
        self.ventana = Tk()

        #Configuracion de ventana
        self.ventana.config(bd=15)
        self.ventana.geometry("1024x600")
        self.ventana.title("Aplicacion de busqueda")
        self.imagen=PhotoImage(file="tp_estruc/estructuradedatos/luquitasperon.png")
        self.foto= Label(self.ventana, image=self.imagen).place(x=-25,y=-10)


        #Lista desplegable

        self.lista_desplegable = ["Predeterminado","Frase exacta","Todas las palabras","Alguna de las palabras",]
        self.lista_formato = ["CSV","JSON","HTML",]

        self.opcion_formato = StringVar(self.ventana)
        self.opcion_formato.set(self.lista_formato[0])
        OptionMenu(self.ventana, self.opcion_formato, *self.lista_formato).place(relx=0.30, rely=0.6, relwidth=0.20, relheight=0.04)


        self.opcion_desplegable = StringVar(self.ventana)
        self.opcion_desplegable.set(self.lista_desplegable[0])
        OptionMenu(self.ventana, self.opcion_desplegable, *self.lista_desplegable).place(relx=0.50, rely=0.6, relwidth=0.20, relheight=0.04)

        #Labels

        self.titulo= Label(self.ventana, text= "TriVAGOS", bg= "Yellow")
        self.titulo.pack()
        self.opciones_de_busqueda= Label(self.ventana,text = "Opciones de Busqueda", bg= "#4F89FD")
        self.opciones_de_busqueda.place(relx=0.4, rely=0.4, relwidth=0.20, relheight=0.04)

        #Caja de texto
        self.cajaTexto= Entry(self.ventana)
        self.cajaTexto.pack(fill="none", expand=True)



        #Check Buttons
        self.mercadolibre = IntVar()
        self.garbarino= IntVar()
        self.fravega= IntVar()
        self.rodo= IntVar()
        self.con_frase_exacta= IntVar()
        self.con_todas_las_palabras= IntVar()
        self.con_alguna_de_las_palabras= IntVar()

        Checkbutton(self.ventana, text="MercadoLibre", variable=self.mercadolibre,
            onvalue=1, offvalue=0).place(relx=0.3, rely=0.5, relwidth=0.10, relheight=0.04)
        Checkbutton(self.ventana, text="Garbarino", variable=self.garbarino,
            onvalue=1, offvalue=0).place(relx=0.4, rely=0.5, relwidth=0.10, relheight=0.04)
        Checkbutton(self.ventana, text="Fravega", variable=self.fravega,
            onvalue=1, offvalue=0).place(relx=0.5, rely=0.5, relwidth=0.10, relheight=0.04)
        Checkbutton(self.ventana, text="Rodo", variable=self.rodo,
            onvalue=1, offvalue=0).place(relx=0.6, rely=0.5, relwidth=0.10, relheight=0.04)




        #MarketPLACE

        self.marketplace1=None
        self.marketplace2=None
        self.marketplace3=None
        self.marketplace4=None



    def obtener_resultado_check_button(self):
        "AGREGUE LA EXCEPTION"
        try:
            if(self.mercadolibre.get()==1):
                self.marketplace1="MercadoLibre"
            else:
                self.marketplace1= None
            if(self.garbarino.get()==1):
                self.marketplace2="Garbarino"
            else:
                self.marketplace2=None
            if(self.fravega.get()==1):
                self.marketplace3="Fravega"
            else:
                self.marketplace3=None
            if(self.rodo.get()==1):
                self.marketplace4="Rodo"
            else:
                self.marketplace4=None


            if(self.marketplace1==None and self.marketplace2==None and self.marketplace3==None and self.marketplace4==None):
                raise AssertionError

        except AssertionError:
            print("Debe seleccionar una tienda para porder realizar la busqueda")
        "AGREGUE LA EXCEPTION"


        # SI TODOS SON NONE TIRA UNA EXCEPTION DONDE DICE Q SI O SI DEBE SELECCIONAR UNO

    def obtener_resultado_caja_de_texto(self):

        self.producto= self.cajaTexto.get()
        return self.producto



    def ejecutar(self):

        self.obtener_resultado_check_button()
        resultado_texto=self.obtener_resultado_caja_de_texto().lower()


        process = CrawlerProcess({

                'USER_AGENT': 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1)',
                'FEED_FORMAT': 'csv',
                'FEED_URI': 'file:tp_estruc/estructuradedatos/auxiliar.csv',

        })

        if (self.marketplace1 == "MercadoLibre"):
            process.crawl(MercadoLibreSpider, busqueda = resultado_texto)

        if (self.marketplace2 == "Garbarino"):
            process.crawl(GarbarinoSpider, busqueda = resultado_texto)

        if (self.marketplace3 == "Fravega"):
            process.crawl(FravegaSpider, busqueda = resultado_texto)

        if (self.marketplace4 == "Rodo"):
            process.crawl(RodoSpider, busqueda = resultado_texto)



        "AGREGAR QUE SI SON TODOS NONE DEJE UN FICHERO VACIO"
        if(self.marketplace1==None and self.marketplace2==None and self.marketplace3==None and self.marketplace4==None):
            with open("C:/Users/Hawk/Desktop/phyton/tp_estruc/estructuradedatos/auxiliar.csv","w")as archivo_vacio:
                puntero=csv.writer(archivo_vacio)
                puntero.writerow("")
        "AGREGAR QUE SI SON TODOS NONE DEJE UN FICHERO VACIO"


        process.start()


        #Cargar archivos del csv
        cargar_archivos= CargarArchivo('auxiliar.csv')

        diccionario = cargar_archivos.obtener_diccionario()


        #Buscador
        buscar_archivos = Buscador(diccionario,self.opcion_desplegable.get(),resultado_texto)


        if (self.opcion_formato.get() == "CSV"):
            buscar_archivos.escribir_en_csv()

        elif(self.opcion_formato.get() == "JSON"):
            buscar_archivos.escribir_en_json()

        else:
            buscar_archivos.escribir_en_html()


        "MODIFIQUE LA RUTA PARA  QUE ELIMINE EL AUXILIAR"
        if(os.path.isfile("tp_estruc/estructuradedatos/auxiliar.csv")== True):
           remove("tp_estruc/estructuradedatos/auxiliar.csv")
        "MODIFIQUE LA RUTA PARA  QUE ELIMINE EL AUXILIAR"

        "Cierra la ventana del buscador"
        self.ventana.destroy()
        "Cierra la ventana del buscador"

    def buscar(self):

        boton_buscar = Button(self.ventana, text = "buscar", command = self.ejecutar)
        boton_buscar.place(x=475, y=500)
        boton_buscar.place(relwidth=0.05, relheight=0.05)
        boton_buscar.pack(expand=True)
        self.ventana.mainloop()


if __name__ == '__main__':
    probando=ventana()
    probando.buscar()

