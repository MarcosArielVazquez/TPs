import json
from datetime import date
from datetime import datetime
import csv
from nltk.corpus import stopwords

class Buscador:

    def __init__(self, archivos_cargados, modo_de_busqueda, busqueda):

        self.archivos_cargados=archivos_cargados
        self.modo_de_busqueda=modo_de_busqueda
        self.busqueda=busqueda
        self.fecha= str(datetime.now().date())
        self.lista_new = []
        self.lista_return = []


    def buscar_articulos(self):

        stop_words = frozenset(stopwords.words('spanish'))

        if(self.modo_de_busqueda == "Predeterminado"):
            claves = list(self.archivos_cargados.keys())
            for elemento in claves:
                self.lista_new.append(self.archivos_cargados[elemento])

            return self.lista_new

        #Frase exacta: Nombredelproducto tiene que ser exactamente igual a la busqueda que planteo el usuario.

        if(self.modo_de_busqueda== "Frase exacta"):
            self.lista_new = []
            claves=list(self.archivos_cargados.keys())
            for elemento in claves:
                if(self.archivos_cargados[elemento][0] == self.busqueda):
                    self.lista_new.append(self.archivos_cargados[elemento])
            return self.lista_new

        #Todas las palabras: La busqueda realizada por el usuario debe ser spliteada y las palabras por separado o juntas deben estar dentro del Nombredelproducto
        if(self.modo_de_busqueda== "Alguna de las palabras"):
            claves = list(self.archivos_cargados.keys())
            self.busqueda = self.normalizar(self.busqueda)
            lista_busqueda = self.busqueda.split(' ')

            self.lista_new = []
            self.lista_return = []

            for palabra in lista_busqueda:
                palabra = self.normalizar(palabra)
                if palabra not in stop_words:
                    self.lista_new.append(palabra)

            for elemento in claves:
                for palabra in self.lista_new:

                    self.archivos_cargados[elemento][0] = self.normalizar(self.archivos_cargados[elemento][0])

                    if(palabra in self.archivos_cargados[elemento][0]):
                        self.lista_return.append(self.archivos_cargados[elemento])
                        break

            return self.lista_return

            #Return dict_nuevo
        #Alguna de las palabras: Con que haya aunque sea una sola palabra dentro de nombredelproducto debe ser devuelto el producto


        if(self.modo_de_busqueda== "Todas las palabras"):
            claves = list(self.archivos_cargados.keys())
            self.busqueda = self.normalizar(self.busqueda)
            lista_busqueda = self.busqueda.split(' ')

            self.lista_new = []
            self.lista_return = []

            for palabra in lista_busqueda:
                palabra = self.normalizar(palabra)
                if palabra not in stop_words:
                    self.lista_new.append(palabra)


            for elemento in claves:

                contador = 0

                for palabra in self.lista_new:

                    self.archivos_cargados[elemento][0] = self.normalizar(self.archivos_cargados[elemento][0])

                    if(palabra in self.archivos_cargados[elemento][0]):
                        contador += 1

                if(contador == len(self.lista_new)):
                    self.lista_return.append(self.archivos_cargados[elemento])

            return self.lista_return


    #Opcional 1 - Como usuario quiero poder especificar el formato de salida de mi informe para tener mayor flexibilidad al momento de utilizar estos datos

    def escribir_en_csv(self):

        self.lista_nuevo = self.buscar_articulos()
        self.ordenar_listas()

        with open(self.busqueda+' '+self.fecha+".csv", 'w',encoding="utf-8") as csvfile: #agregue utf8
            writer = csv.writer(csvfile, delimiter=';')
            writer.writerows(self.lista_nuevo)

    def escribir_en_json(self):

        self.lista_nuevo=self.buscar_articulos()
        self.ordenar_listas()

        with open(self.busqueda+' '+self.fecha+".json", 'w',encoding="utf-8") as jsonfile: #agregue utf8
            try:
                json.dump(self.lista_nuevo, jsonfile)
            except:
                print ("Este objeto no puede ser persistido con por JSON: Por favor revise los objetos permitidos")

    def escribir_en_html(self):

        self.lista_nuevo= self.buscar_articulos()
        self.ordenar_listas()

        with open(self.busqueda+' '+self.fecha+".html", 'w',encoding="utf-8")as htmlfile:
            for line in self.lista_nuevo:
                htmlfile.writelines(str(line)+'\n')


    def ordenar_listas(self,):
        self.lista_nuevo= sorted(self.lista_nuevo, key = lambda x:x[0]== self.busqueda or x[0] in self.busqueda, reverse = True)


    def normalizar(self, s):
        replacements = (
            ("á", "a"),
            ("é", "e"),
            ("í", "i"),
            ("ó", "o"),
            ("ú", "u"),
        )
        for a, b in replacements:
            s = s.replace(a, b).replace(a.upper(), b.upper())

        s = s.lower()

        return s
    '''def opcional_2_a(self, csv_1, csv_2, csv_3 = None, csv_4= None, usar_diccionarios = False):
        self.nombre_tienda = csv_1.split(".")[0]
        self.nombre_tienda_dos = csv_2.split(".")[0]


        self.dicc_csv_1 = {}
        self.dicc_csv_2 = {}

        with open (csv_1) as primer_market:
            reader1 = csv.reader(primer_market)
            for linea in reader1:
                if linea[1] != "titulo":
                    self.dicc_csv_1[linea[1]] = [linea[0], linea[2]]
                    #lista_csv_1.append(linea[1])

        with open(csv_2) as segundo_market:
            reader2 = csv.reader(segundo_market)
            for linea in reader2:

                if linea[1] != "titulo":
                    self.dicc_csv_2[linea[1]] = [linea[0], linea[2]]
                    #lista_csv_2.append(linea[0])


        if csv_3 != None:
            self.nombre_tienda_tres = csv_3.split(".")[0]
            self.dicc_csv_3 = {}
            with open(csv_3) as tercer_market:
                reader3 = csv.reader(tercer_market)
                for linea in reader3:
                    if linea[1] != "titulo":
                        self.dicc_csv_3[linea[1]] = [linea[0], linea[2]]
            if csv_4 == None and usar_diccionarios == False:
                return self.__comparar_dicc(self.dicc_csv_1, self.dicc_csv_2,self.dicc_csv_3)

        if csv_3 != None and csv_4 != None:
            self.nombre_tienda_cuatro = csv_4.split(".")[0]
            self.dicc_csv_4 = {}
            with open(csv_4) as cuarto_market:
                reader4 = csv.reader(cuarto_market)
                for linea in reader4:
                    if linea[1] != "titulo":
                        self.dicc_csv_4[linea[1]] = [linea[0], linea[2]]
            if usar_diccionarios == False:
                return self.__comparar_dicc(self.dicc_csv_1, self.dicc_csv_2, self.dicc_csv_3, self.dicc_csv_4)

        if usar_diccionarios == False:
            return self.__comparar_dicc(self.dicc_csv_1, self.dicc_csv_2)


    def __comparar_dicc(self, dicc_1, dicc_2, dicc_3 = None, dicc_4 = None):

        if dicc_3 == None and dicc_4 == None:

            comparacion = {}

            for key in dicc_1:
                if key in dicc_2:
                    comparacion[self.nombre_tienda] = [key,dicc_1[key][0],dicc_1[key][1]]
                    comparacion[self.nombre_tienda_dos] = [key, dicc_2[key][0], dicc_2[key][1]]

            return comparacion

        if dicc_3 != None and dicc_4 == None:
            comparacion = {}
            for key in dicc_1:
                if key in dicc_2 and key in dicc_3:
                    comparacion[self.nombre_tienda] = [key, dicc_1[key][0], dicc_1[key][1]]
                    comparacion[self.nombre_tienda_dos] = [key, dicc_2[key][0], dicc_2[key][1]]
                    comparacion[self.nombre_tienda_tres] = [key, dicc_3[key][0], dicc_3[key][1]]

            return comparacion

        if dicc_3 != None and dicc_4 != None:

            comparacion = {}

            for key in dicc_1:
                if key in dicc_2 and key in dicc_3 and key in dicc_4:
                    comparacion[self.nombre_tienda] = [key, dicc_1[key][0], dicc_1[key][1]]
                    comparacion[self.nombre_tienda_dos] = [key, dicc_2[key][0], dicc_2[key][1]]
                    comparacion[self.nombre_tienda_tres] = [key, dicc_3[key][0], dicc_3[key][1]]
                    comparacion[self.nombre_tienda_cuatro] = [key,dicc_4[key][0], dicc_4[key][1]]

            return comparacion


    def opcional_3_a(self,articulo, csv_1,csv_2, csv_3 = None, csv_4 = None):
        self.opcional_2_a(csv_1, csv_2,csv_3,csv_4, True)

        self.articulos_iguales = {}

        self.__dividir_articulos_primera_tienda(articulo)
        self.__dividir_articulos_segunda_tienda(articulo)

        if csv_3 != None:
            self.__dividir_articulos_tercera_tienda(articulo)

        if csv_4 != None:
            self.__dividir_articulos_cuarta_tienda(articulo)

        self.__ordenar_por_precio_menores()

        #print(self.articulos_iguales)


    def __dividir_articulos_primera_tienda(self,articulo):

        if articulo.islower() == False:
            articulo = articulo.lower()

        if self.nombre_tienda == "Fravega":
            for key in self.dicc_csv_1:
                precio_sin_punto = self.dicc_csv_1[key][0].split(".")
                precio = self.__obtener_precio(precio_sin_punto)
                self.precios_para_promediar["Fravega"].append(precio)
                if articulo in key:
                    self.articulos_iguales[key] = [precio,self.dicc_csv_1[key][1]]

        elif self.nombre_tienda == "Garbarino":
            for key in self.dicc_csv_1:
                precio_sin_punto = self.dicc_csv_1[key][0].split(".")
                precio = self.__obtener_precio(precio_sin_punto)
                self.precios_para_promediar["Garbarino"].append(precio)
                if articulo in key:
                    self.articulos_iguales[key] = [precio, self.dicc_csv_1[key][1]]

        elif self.nombre_tienda == "MercadoLibre":
            for key in self.dicc_csv_1:
                precio_sin_punto = self.dicc_csv_1[key][0].split(".")
                precio = self.__obtener_precio(precio_sin_punto)
                self.precios_para_promediar["MercadoLibre"].append(precio)
                if articulo in key:
                    self.articulos_iguales[key] = [precio, self.dicc_csv_1[key][1]]

        elif self.nombre_tienda == "Rodo":
            for key in self.dicc_csv_1:
                precio_sin_punto = self.dicc_csv_1[key][0].split(".")
                precio = self.__obtener_precio(precio_sin_punto)
                self.precios_para_promediar["Rodo"].append(precio)
                if articulo in key:
                    self.articulos_iguales[key] = [precio, self.dicc_csv_1[key][1]]



    def __dividir_articulos_segunda_tienda(self,articulo):

        if articulo.islower() == False:
            articulo = articulo.lower()

        if self.nombre_tienda_dos == "Fravega":
            for key in self.dicc_csv_2:
                precio_sin_punto = self.dicc_csv_2[key][0].split(".")
                precio = self.__obtener_precio(precio_sin_punto)
                self.precios_para_promediar["Fravega"].append(precio)
                if articulo in key:
                    self.articulos_iguales[key] = [precio, self.dicc_csv_2[key][1]]


        elif self.nombre_tienda_dos == "Garbarino":
            for key in self.dicc_csv_2:
                precio_sin_punto = self.dicc_csv_2[key][0].split(".")
                precio = self.__obtener_precio(precio_sin_punto)
                self.precios_para_promediar["Garbarino"].append(precio)
                if articulo in key:
                    self.articulos_iguales[key] = [precio, self.dicc_csv_2[key][1]]

        elif self.nombre_tienda_dos == "MercadoLibre":
            for key in self.dicc_csv_2:
                precio_sin_punto = self.dicc_csv_2[key][0].split(".")
                precio = self.__obtener_precio(precio_sin_punto)
                self.precios_para_promediar["MercadoLibre"].append(precio)
                if articulo in key:
                    self.articulos_iguales[key] = [precio, self.dicc_csv_2[key][1]]

        elif self.nombre_tienda_dos == "Rodo":
            for key in self.dicc_csv_2:
                precio_sin_punto = self.dicc_csv_2[key][0].split(".")
                precio = self.__obtener_precio(precio_sin_punto)
                self.precios_para_promediar["Rodo"].append(precio)
                if articulo in key:
                    self.articulos_iguales[key] = [precio, self.dicc_csv_2[key][1]]



    def __dividir_articulos_tercera_tienda(self,articulo):

        if articulo.islower() == False:
            articulo = articulo.lower()

        if self.nombre_tienda_tres == "Fravega":
            for key in self.dicc_csv_3:
                precio_sin_punto = self.dicc_csv_3[key][0].split(".")
                precio = self.__obtener_precio(precio_sin_punto)
                self.precios_para_promediar["Fravega"].append(precio)
                if articulo in key:
                    self.articulos_iguales[key] = [precio, self.dicc_csv_3[key][1]]

        elif self.nombre_tienda_tres == "Garbarino":
            for key in self.dicc_csv_3:
                precio_sin_punto = self.dicc_csv_3[key][0].split(".")
                precio = self.__obtener_precio(precio_sin_punto)
                self.precios_para_promediar["Garbarino"].append(precio)
                if articulo in key:
                    self.articulos_iguales[key] = [precio, self.dicc_csv_3[key][1]]

        elif self.nombre_tienda_tres == "MercadoLibre":
            for key in self.dicc_csv_3:
                precio_sin_punto = self.dicc_csv_3[key][0].split(".")
                precio = self.__obtener_precio(precio_sin_punto)
                self.precios_para_promediar["MercadoLibre"].append(precio)
                if articulo in key:
                    self.articulos_iguales[key] = [precio, self.dicc_csv_3[key][1]]

        elif self.nombre_tienda_tres == "Rodo":
            for key in self.dicc_csv_3:
                precio_sin_punto = self.dicc_csv_3[key][0].split(".")
                precio = self.__obtener_precio(precio_sin_punto)
                self.precios_para_promediar["Rodo"].append(precio)
                if articulo in key:
                    self.articulos_iguales[key] = [precio, self.dicc_csv_3[key][1]]



    def __dividir_articulos_cuarta_tienda(self, articulo):

        if articulo.islower() == False:
            articulo = articulo.lower()

        if self.nombre_tienda_cuatro == "Fravega":
            for key in self.dicc_csv_4:
                precio_sin_punto = self.dicc_csv_4[key][0].split(".")
                precio = self.__obtener_precio(precio_sin_punto)
                self.precios_para_promediar["Fravega"].append(precio)
                if articulo in key:
                    self.articulos_iguales[key] = [precio, self.dicc_csv_4[key][1]]

        elif self.nombre_tienda_cuatro == "Garbarino":
            for key in self.dicc_csv_4:
                precio_sin_punto = self.dicc_csv_4[key][0].split(".")
                precio = self.__obtener_precio(precio_sin_punto)
                self.precios_para_promediar["Garbarino"].append(precio)
                if articulo in key:
                    self.articulos_iguales[key] = [precio,self.dicc_csv_4[key][1]]

        elif self.nombre_tienda_cuatro == "MercadoLibre":
            for key in self.dicc_csv_4:
                precio_sin_punto = self.dicc_csv_4[key][0].split(".")
                precio = self.__obtener_precio(precio_sin_punto)
                self.precios_para_promediar["MercadoLibre"].append(precio)
                if articulo in key:
                    self.articulos_iguales[key] = [precio,self.dicc_csv_4[key][1]]

        elif self.nombre_tienda_cuatro == "Rodo":
            for key in self.dicc_csv_4:
                precio_sin_punto = self.dicc_csv_4[key][0].split(".")
                precio = self.__obtener_precio(precio_sin_punto)
                self.precios_para_promediar["Rodo"].append(precio)
                if articulo in key:
                    self.articulos_iguales[key] = [precio,self.dicc_csv_4[key][1]]




    def __obtener_precio(self,precio_para_verificar):
        if len(precio_para_verificar) < 2:
            precio = int(precio_para_verificar[0])
        else:
            precio = int(precio_para_verificar[0]+precio_para_verificar[1])

        return precio

    def __ordenar_por_precio_menores(self):
        self.articulos_iguales = dict(sorted(self.articulos_iguales.items(), key = lambda x:x[1][0], reverse= False))
    '''