package Exceptions;

public class ValorInvalido  extends Exception{
	
	public ValorInvalido(String e){
		super(e);
	}

}
