package Exceptions;

public class AccesoBloqueado extends Exception {
	public AccesoBloqueado(String e){
		super(e);
	}
}
