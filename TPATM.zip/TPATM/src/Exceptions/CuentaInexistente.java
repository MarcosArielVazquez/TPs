package Exceptions;

public class CuentaInexistente extends Exception {
	
	public CuentaInexistente(String e){
		super(e);
	}
}
