package CodigoFuente;

import java.io.IOException;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

public class Movimiento {
	private Calendar fecha = new GregorianCalendar();
	private Cliente clienteActual;
	private String movimiento;
	private String dia;
	private String mes;
	private String a�o;
	
	public Movimiento(Cliente unCliente,String movimiento) throws IOException {
		clienteActual=unCliente;
		this.movimiento=movimiento;
		obtenerDia();
		obtenerMes();
		obtenerA�o();
	}
	public String obtenerDia(){
		
		dia= fecha.get(Calendar.DAY_OF_MONTH)+"";
		return dia;
	}
	public String obtenerMes(){
	
		mes= (fecha.get(Calendar.MONTH)+1)+"";
		return mes;
	}
	public String obtenerA�o(){
		
		a�o=fecha.get(Calendar.YEAR)+"";
		return a�o;
	}
	
	public String obtenerAlias(){
		return clienteActual.obtenerTarjeta().obtenerCuenta().obtenerAlias();
	}
	public String obtenerSaldo(){
		return clienteActual.obtenerTarjeta().obtenerCuenta().obtenerSaldo()+"";
	}
	public String obtenerOperacion(){
		return movimiento;
	}
	
}

